from __future__ import annotations
import collections.abc
import datetime
import typing
from warnings import deprecated # type: ignore

import jpype # type: ignore
import jpype.protocol # type: ignore

import ghidra.app.util.html.diff
import ghidra.program.model.data
import java.awt # type: ignore
import java.lang # type: ignore
import java.util # type: ignore


class HTMLDataTypeRepresentation(java.lang.Object):

    class_: typing.ClassVar[java.lang.Class]

    def diff(self, otherRepresentation: HTMLDataTypeRepresentation) -> jpype.JArray[HTMLDataTypeRepresentation]:
        """
        Compares this representation and the given representation creates a diff string for both
        representations.
        
        :param HTMLDataTypeRepresentation otherRepresentation: the other representation to diff against.
        :return: An array of two strings: the first is this object's diff value, the second is the
                given objects diff value.
        :rtype: jpype.JArray[HTMLDataTypeRepresentation]
        """

    def getFullHTMLContentString(self) -> str:
        """
        This is like :meth:`getHTMLString() <.getHTMLString>`, but does not put HTML tags around the data
        
        :return: the content
        :rtype: str
        """

    def getFullHTMLString(self) -> str:
        """
        Returns an HTML string for this data representation object
        
        :return: the html
        :rtype: str
        
        .. seealso::
        
            | :obj:`.getHTMLString()`
        """

    def getHTMLContentString(self) -> str:
        """
        This is like :meth:`getHTMLString() <.getHTMLString>`, but does not put HTML tags around the data
        
        :return: the content
        :rtype: str
        """

    def getHTMLString(self) -> str:
        """
        Returns an HTML string for this data representation object.  The HTML returned will be
        truncated if it is too long.   To get the full HTML, call :meth:`getFullHTMLString() <.getFullHTMLString>`.
        
        :return: the html
        :rtype: str
        
        .. seealso::
        
            | :obj:`.getFullHTMLString()`
        """

    @property
    def fullHTMLString(self) -> java.lang.String:
        ...

    @property
    def hTMLString(self) -> java.lang.String:
        ...

    @property
    def fullHTMLContentString(self) -> java.lang.String:
        ...

    @property
    def hTMLContentString(self) -> java.lang.String:
        ...


class TextLine(ValidatableLine):

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self, text: typing.Union[java.lang.String, str]) -> None:
        ...

    def getTextColor(self) -> java.awt.Color:
        ...

    @property
    def textColor(self) -> java.awt.Color:
        ...


class ValidatableLine(java.lang.Object):
    """
    A loose concept that represents a line of text, potentially with multiple parts, that can
    be validated against other instances and can change the color of the text.
     
    
    Validation is performed against another :obj:`ValidatableLine`, which will be set by 
    calling :meth:`setValidationLine(ValidatableLine) <.setValidationLine>`.
    """

    class_: typing.ClassVar[java.lang.Class]
    INVALID_COLOR: typing.Final[java.awt.Color]

    def copy(self) -> ValidatableLine:
        ...

    def getText(self) -> str:
        ...

    def isDiffColored(self) -> bool:
        ...

    def isValidated(self) -> bool:
        """
        True means that this line has been matched against another line, **regardless of whether 
        the two lines are the same or not**.
        
        :return: true if this line has been matched against another line
        :rtype: bool
        """

    def matches(self, otherLine: ValidatableLine) -> bool:
        ...

    def setTextColor(self, color: java.awt.Color) -> None:
        """
        Set color for all text.
        
        :param java.awt.Color color: text color
        """

    def setValidationLine(self, line: ValidatableLine) -> None:
        """
        Sets the other line that this line is validated against.  The other line may be a full, 
        partial, or no match at all.
        
        :param ValidatableLine line: the line against which this line is validated
        """

    def updateColor(self, otherLine: ValidatableLine, invalidColor: java.awt.Color) -> None:
        ...

    @property
    def validated(self) -> jpype.JBoolean:
        ...

    @property
    def text(self) -> java.lang.String:
        ...

    @property
    def diffColored(self) -> jpype.JBoolean:
        ...


class HTMLDataTypeRepresentationDiffInput(ghidra.app.util.html.diff.DataTypeDiffInput):

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self, source: HTMLDataTypeRepresentation, lines: java.util.List[ValidatableLine]) -> None:
        ...


class PlaceHolderLine(ValidatableLine):
    """
    Marker interface for lines that are generic place holders for diffing
    """

    class_: typing.ClassVar[java.lang.Class]


class ArrayDataTypeHTMLRepresentation(HTMLDataTypeRepresentation):

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self, array: ghidra.program.model.data.Array) -> None:
        ...


class BitFieldDataTypeHTMLRepresentation(HTMLDataTypeRepresentation):

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self, bitFieldDt: ghidra.program.model.data.BitFieldDataType) -> None:
        ...


class CompletelyDifferentHTMLDataTypeRepresentationWrapper(HTMLDataTypeRepresentation):
    ...
    class_: typing.ClassVar[java.lang.Class]


class CompositeDataTypeHTMLRepresentation(HTMLDataTypeRepresentation):

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self, comp: ghidra.program.model.data.Composite) -> None:
        ...


class DataTypeLine(ValidatableLine):

    class_: typing.ClassVar[java.lang.Class]

    def getComment(self) -> str:
        ...

    def getCommentColor(self) -> java.awt.Color:
        ...

    def getDataType(self) -> ghidra.program.model.data.DataType:
        ...

    def getName(self) -> str:
        ...

    def getNameColor(self) -> java.awt.Color:
        ...

    def getType(self) -> str:
        ...

    def getTypeColor(self) -> java.awt.Color:
        ...

    def hasUniversalId(self) -> bool:
        ...

    def setCommentColor(self, commentColor: java.awt.Color) -> None:
        ...

    def setNameColor(self, nameColor: java.awt.Color) -> None:
        ...

    def setTypeColor(self, typeColor: java.awt.Color) -> None:
        ...

    @property
    def typeColor(self) -> java.awt.Color:
        ...

    @typeColor.setter
    def typeColor(self, value: java.awt.Color):
        ...

    @property
    def nameColor(self) -> java.awt.Color:
        ...

    @nameColor.setter
    def nameColor(self, value: java.awt.Color):
        ...

    @property
    def dataType(self) -> ghidra.program.model.data.DataType:
        ...

    @property
    def name(self) -> java.lang.String:
        ...

    @property
    def comment(self) -> java.lang.String:
        ...

    @property
    def commentColor(self) -> java.awt.Color:
        ...

    @commentColor.setter
    def commentColor(self, value: java.awt.Color):
        ...

    @property
    def type(self) -> java.lang.String:
        ...


class DefaultDataTypeHTMLRepresentation(HTMLDataTypeRepresentation):

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self, dataType: ghidra.program.model.data.DataType) -> None:
        ...


class EmptyDataTypeLine(DataTypeLine, PlaceHolderLine):

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self) -> None:
        ...


class EmptyTextLine(TextLine, PlaceHolderLine):

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self, widthInCharacters: typing.Union[jpype.JInt, int]) -> None:
        ...


class EmptyVariableTextLine(VariableTextLine, PlaceHolderLine):

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self, numberOfCharacters: typing.Union[jpype.JInt, int]) -> None:
        ...


class VariableTextLine(ValidatableLine):

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self, variableType: typing.Union[java.lang.String, str], variableName: typing.Union[java.lang.String, str], dataType: ghidra.program.model.data.DataType) -> None:
        ...

    def getDataType(self) -> ghidra.program.model.data.DataType:
        ...

    def getVariableName(self) -> str:
        ...

    def getVariableNameColor(self) -> java.awt.Color:
        ...

    def getVariableType(self) -> str:
        ...

    def getVariableTypeColor(self) -> java.awt.Color:
        ...

    def hasUniversalId(self) -> bool:
        ...

    @property
    def variableType(self) -> java.lang.String:
        ...

    @property
    def variableName(self) -> java.lang.String:
        ...

    @property
    def variableNameColor(self) -> java.awt.Color:
        ...

    @property
    def dataType(self) -> ghidra.program.model.data.DataType:
        ...

    @property
    def variableTypeColor(self) -> java.awt.Color:
        ...


class EnumDataTypeHTMLRepresentation(HTMLDataTypeRepresentation):

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self, enumDataType: ghidra.program.model.data.Enum) -> None:
        ...


class FunctionDataTypeHTMLRepresentation(HTMLDataTypeRepresentation):

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self, functionDefinition: ghidra.program.model.data.FunctionDefinition) -> None:
        ...


class MissingArchiveDataTypeHTMLRepresentation(HTMLDataTypeRepresentation):

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self, sourceArchive: ghidra.program.model.data.SourceArchive) -> None:
        ...


class NullDataTypeHTMLRepresentation(HTMLDataTypeRepresentation):

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self) -> None:
        ...


class PointerDataTypeHTMLRepresentation(HTMLDataTypeRepresentation):

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self, pointer: ghidra.program.model.data.Pointer) -> None:
        ...


class TypeDefDataTypeHTMLRepresentation(HTMLDataTypeRepresentation):

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self, typeDef: ghidra.program.model.data.TypeDef) -> None:
        ...



__all__ = ["HTMLDataTypeRepresentation", "TextLine", "ValidatableLine", "HTMLDataTypeRepresentationDiffInput", "PlaceHolderLine", "ArrayDataTypeHTMLRepresentation", "BitFieldDataTypeHTMLRepresentation", "CompletelyDifferentHTMLDataTypeRepresentationWrapper", "CompositeDataTypeHTMLRepresentation", "DataTypeLine", "DefaultDataTypeHTMLRepresentation", "EmptyDataTypeLine", "EmptyTextLine", "EmptyVariableTextLine", "VariableTextLine", "EnumDataTypeHTMLRepresentation", "FunctionDataTypeHTMLRepresentation", "MissingArchiveDataTypeHTMLRepresentation", "NullDataTypeHTMLRepresentation", "PointerDataTypeHTMLRepresentation", "TypeDefDataTypeHTMLRepresentation"]
